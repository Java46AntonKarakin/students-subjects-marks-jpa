package telran.spring.data.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "students")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class StudentEntity {
	@Id
	long id;
	
	@Column(unique = true)
	String name;
	
	
	
}
