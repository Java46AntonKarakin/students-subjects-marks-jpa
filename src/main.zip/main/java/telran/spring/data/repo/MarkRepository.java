package telran.spring.data.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import telran.spring.data.entities.MarkEntity;
import telran.spring.data.proj.MarkProj;
import telran.spring.data.proj.StudentSubjectMark;

public interface MarkRepository extends JpaRepository<MarkEntity, Long>{

	List<MarkProj> findByStudentNameAndSubjectSubject(String name, String subject);
	@Query(value = "SELECT student.name, subject.subject, mark " + 
			" FROM students student" +
			" JOIN marks ON student.stid=marks.stid" + 
			" JOIN subjects subject ON subject.suid=marks.suid" + 
			" WHERE student.name=:name",
			nativeQuery = true)
	List<StudentSubjectMark> findByStudentName(String name);

}
