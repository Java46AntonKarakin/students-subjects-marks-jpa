package telran.spring.data.proj;

public interface MarkProj {
	Integer getMark();
}
