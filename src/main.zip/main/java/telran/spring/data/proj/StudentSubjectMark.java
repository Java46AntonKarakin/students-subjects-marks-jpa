package telran.spring.data.proj;

public interface StudentSubjectMark {
	String getName();

	String getSubject();

	Integer getMark();
}
