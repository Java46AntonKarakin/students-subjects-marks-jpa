package telran.spring.data.model;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class Mark {
	
	public long stid;
	public long suid;
	public int mark;
}
